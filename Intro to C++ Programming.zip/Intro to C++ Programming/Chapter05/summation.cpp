// Lab 5 - summation.cpp
// This program displays a series of terms and computes its sum.
// PUT YOUR NAME HERE.                        
#include <iostream>
#include <cmath>
using namespace std;

int main()
{     
	int denom,            	// Denominator of a particular term
       finalDenom = 64;    // Denominator of the final term
	double sum = 0.0;		   // Accumulator that adds up all terms in the series
  	
   cout << "PUT YOUR NAME HERE. \n";
   
   // WRITE THE CODE TO START A FOR LOOP THAT LOOPS ONCE FOR EACH TERM.
   // I.E., FOR TERMS WITH DENOMINATORS FROM 2 TO THE FINAL DENOMINATOR.
	{
		// WRITE THE CODE TO PRINT THIS TERM.
		// IF IT IS NOT THE LAST TERM, FOLLOW IT WITH A +.
      // IF IT IS THE LAST TERM, FOLLOW IT WITH A =.
      
      // WRITE THE CODE TO ADD THE VALUE OF THIS TERM TO THE ACCUMULATOR.
   }
	
	// WRITE A LINE OF CODE TO PRINT THE SUM. 	
	      
	return 0;
}
