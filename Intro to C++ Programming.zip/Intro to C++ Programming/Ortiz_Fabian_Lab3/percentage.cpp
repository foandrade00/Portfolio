// Lab 3 percentage.cpp
// This program will determine the percentage 
// of answers a student got correct on a test.
// Ortiz
//Fabian
//ITI C++ Fall 2020
// October 12,2000 

// INCLUDE THE FILE NEEDED TO DO I/O
#include <iostream>

// INCLUDE THE FILE NEEDED TO FORMAT OUTPUT
#include <fstream>

// INCLUDE THE FILE NEEDED TO USE STRINGS
#include <string>
#include <cmath>


using namespace std;

int main()
{
   string fname, lname,name;
   float numQuestions,
       numCorrect;
   double percentage;
   
   // Get student's test data
   cout << "Enter student's first and last name: ";
   
   cin >> fname >> lname;
   
   
   
   // WRITE A STATEMENT TO READ THE WHOLE NAME INTO THE name VARIABLE.
   
   cout << "Number of questions on the test: " << endl;
   cin  >> numQuestions;
   cout << "Number of answers the student got correct: " << endl;
   cin  >> numCorrect;
   
   // Compute and display the student's % correct
   // WRITE A STATEMENT TO COMPUTE THE % AND ASSIGN THE RESULT TO percentage.
    percentage = (numCorrect / numQuestions) * 100;   
   // WRITE STATEMENTS TO DISPLAY THE STUDENT'S NAME AND THEIR TEST 
   // PERCENTAGE WITH ONE DECIMAL POINT. 
    cout << fname << " " << lname << " " << percentage << "%" << " ";
   
   
   return 0;
}


/*  Step 2 and 3 
	Run 1:  John Smith   40  31 --> John Smith 77.5%

	Run 2:  Mary Jones   20  19 --> Mary Jones 95% ( not sure if 19 was the total number of questoins? so I switched the values)

	Run 3:  Juan Sanchez 12  11 --> Juan Sanchez 91.6667%  ( not sure if 11 was the total number of questoins? so I switched the values)
 */
