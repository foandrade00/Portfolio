//ORTIZ
//FABIAN
// ITI 2410 C++ FALL 2020
//October 28, 2020
// Lab 3 tryIt3A -- Evaluating arithmetic expressions
// Determine what each output statement will print. Then run 
// the program to see if you are correct. If any of your answers 
// are wrong, figure out why the program behaved as it did.
#include <iostream>
#include <cmath>
using namespace std;

int main()
{   int someInt,
		  w = 5, x = 9, y = 2, z = 7;

	 char someChar = 'A';

	 cout << "tryIt3A output \n";              //give output on diff line  tryIt3A output

	 z += 3;
	 cout << z << "  " << z % w << endl;       // z/w                       10  0

	 z *= w + y;
	 cout << z << endl;                        // multiply 12x7             70

	 z -= 60.1;
	 cout << z << endl;                        // -53.1                     9

	 cout << (x-1) / (x-w) * y << endl;        //9/4*2                      1
            
	 cout << (x-1) / ((x-w) * y) << endl;      //9/4*2                      4.5

	 cout << static_cast<double>(x) / y << endl;  //x/y                     4

	 cout << x / y << endl;                    //9/2                        6

	 cout << (w + x % 7 / y) << endl;          //5/9%7/2                    6
    
	 cout << (abs(y - w) + sqrt(x)) << endl;   //     2-5+sqrtx

	 someInt = someChar;                       // Chart
	 cout << someChar << "  "
			<< someInt << endl;
                                               //build chart                A 65
    return 0;
}
