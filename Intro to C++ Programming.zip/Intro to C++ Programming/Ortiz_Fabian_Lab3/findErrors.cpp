// Lab 3 findErrors.cpp
// This program contains many syntax errors and will not compile.
// Fix the errors so that it correctly finds the average of the
// two integers the user enters. 
// Ortiz
//Fabian
//ITI 2410 C++ Fall 2020
//October 28, 2020

#include <iostream>
using namespace std;

int main()
{
   double num1; int num2;
   double sum, average;
   
   // Input 2 integers
   cout << "Enter two integers separated by one or more spaces: ";
   cin  >> num1 >> num2;

  // Find and display their average
   sum = num1+ num2;
   average = sum / 2;
  // cout << (num1 + num2) / 2 =  << average;
   cout << "Sum = " << sum << endl;
   cout << "Average = " << average;
   cout << "\nThe average of these 2 numbers is " << average << endl;
   
   return 0;
}
//Enter two integers separated by one or more spaces: 6 8
//Sum = 14
//Average = 7
//The average of these 2 numbers is 7
//Enter two integers separated by one or more spaces: 0 -2
//Sum = -2
//Average = -1
//The average of these 2 numbers is -1
//Enter two integers separated by one or more spaces: 7 8
//Sum = 15
//Average = 7.5
//The average of these 2 numbers is 7.5