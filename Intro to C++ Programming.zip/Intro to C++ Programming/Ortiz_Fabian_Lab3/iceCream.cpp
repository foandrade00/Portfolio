//Ortiz
//Fabian
//ITI 2410 C++ Fall 2020
// October 29, 2020

// Lab 3 icecream.cpp 
// WRITE A COMMENT BRIEFLY DESCRIBING THE PROGRAM. 

// INCLUDE ANY NEEDED FILES HERE.
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

int main()
{  
   // DEFINE NAMED CONSTANTS HERE TO HOLD THE PRICES OF THE 3

   // SIZES OF ICE CREAM CONES. GIVE EACH ONE A DESCRIPTIVE
   // NAME AND AN APPROPRIATE DATA TYPE. 

   float onescoop, twoscoop, triscoop,oneamount,twoamount,triamount,onetotal,
   twototal,tritotal,grandtotal,grandamount;

   onescoop = 1.49;
   twoscoop = 2.49;
   triscoop = 3.49;
   
   // DECLARE ALL NEEDED VARIABLES HERE. GIVE EACH ONE A DESCRIPTIVE
   // NAME AND AN APPROPRIATE DATA TYPE. 
   
   // WRITE STATEMENTS HERE TO PROMPT FOR AND INPUT THE INFORMATION
   // THE PROGRAM NEEDS TO GET FROM THE USER.

   cout << "Write the number of single scoop cones sold?" << endl;
   cin >> oneamount;
   cout << "Write the number of double scoop cones sold?" << endl;
   cin >> twoamount;
   cout << "Write the number of tripple scoop cones sold?" << endl;
   cin >> triamount;

cout << "Number of single scoop cones Sold : " << oneamount << endl;
cout << "Number of double scoop cones Sold : " << twoamount << endl;
cout << "Number of triple scoop cones Sold : " << triamount << endl << endl;


onetotal = onescoop * oneamount;
twototal = twoscoop * twoamount;
tritotal = triscoop * triamount;



grandamount = oneamount + twoamount + triamount;
grandtotal = onetotal + twototal + tritotal;

cout << "DeLIGHTful cones"<< setw(10) << oneamount << setw(4)  << "$" << onetotal << endl;

cout << "Double Delight cones"<< setw(10) << twoamount << setw(4)  << "$" <<  twototal << endl;
cout << "Triple Delight cones"<< setw(10) << triamount << setw(4)  <<  "$" <<  tritotal << endl;
cout << "Total" << setw(10)  <<  grandamount << setw(4)  << "$" <<  grandtotal; 



  



   
   // WRITE STATEMENTS HERE TO PERFORM ALL NEEDED COMPUTATIONS  
   // AND ASSIGN THE RESULTS TO VARIABLES.
   
   // WRITE STATEMENTS HERE TO DISPLAY THE REQUESTED INFORMATION.
      
   return 0;
}
