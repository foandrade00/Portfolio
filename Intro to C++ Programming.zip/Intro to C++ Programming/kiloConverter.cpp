/*Ortiz
 Fabian
 ITI 2410 Intro to C++
 November 19, 2020
 */
// Lab 6 kiloConverter.cpp 
// This menu-driven program lets the user convert 
// pounds to kilograms and kilograms to pounds.
// PUT YOUR NAME HERE.
#include <iostream>
#include <string>
using namespace std;

void displayMenu();
int getChoice (int min, int max);
void kilosToPounds(float pnd ,char &answer);
void poundsToKilos(float Kilo, char &answer);



int main()
{
   char answer;
   float Kilo,pnd,temp;
   int menu;
   do{

 displayMenu();
 menu = getChoice(1,3);

switch (menu){


case 1:
   poundsToKilos(Kilo,answer);
   break;
case 2:
   kilosToPounds(pnd,answer);
   break;
case 3:
   cout << " \n You picked quit";
      break;

default:
   cout << "\n This is not a valid input please try again.";
   break; 

}


   }
   while (answer == 'Y' || answer == 'y');

     
   return 0;
}

void displayMenu()
{
int menu;
cout << "Choose a menu option by entering a number. 3 will quit the program. \n\n";
   cout << "1 Convert kilograms to pounds \n" << "2 Convert pounds to kilograms \n" << "3 Quit \n" ;

}

int getChoice(int min,int max)
{
   int input;

   do{   
   
   cout << "Enter an integer between 1 and 3.";
      cin >> input;


      if (input < min || input > max)

   {  cout << "Invalid number enter an integer between 1 and 3 .";

      cin  >> input;
   }
     }
   while (input < min || input > max);
                                        return input;
} 

void kilosToPounds(float pnd,char &answer)
{

float Kilo;
cout << "How many Kilos do you have?";
cin >> Kilo;
pnd = Kilo / 0.45359237;
cout << Kilo << " Kilos is " << pnd << " Pounds."  << endl ;
cout << "Do you want to pick again? Y/N ";
      cin >> answer;

}

void poundsToKilos(float Kilo,char &answer)
{
float pnd;
cout << "How many pounds do you have?";
cin >> pnd;
Kilo = pnd * 0.45359237;
cout << pnd << " pounds is " << Kilo <<  " Kilos" << endl ;
cout << "Do you want to pick again? Y/N ";
      cin >> answer;
}

