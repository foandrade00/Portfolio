// Lab 6 kiloConverter.cpp 
// This menu-driven program lets the user convert 
// pounds to kilograms and kilograms to pounds.
// PUT YOUR NAME HERE.
#include <iostream>
using namespace std;

// Function prototypes
// WRITE PROTOTYPES FOR THE displayMenu, getChoice,
// kilosToPounds and poundsToKilos FUNCTIONS HERE.

/*****     main     *****/
int main()
{
   // DECLARE ANY VARIABLES MAIN USES HERE.
   
   // WRITE THE CODE HERE TO CARRY OUT THE STEPS
   // REQUIRED BY THE PROGRAM SPECIFICATIONS.
     
   return 0;
}

/*****     displayMenu     *****/
// WRITE THE displayMenu FUNCTION HERE.
// THIS void FUNCTION DISPLAYS THE MENU CHOICES
//  1. Convert kilograms to pounds
//  2. Convert pounds to kilograms
//  3. Quit

/*****     getChoice     *****/
// THIS IS THE SAME FUNCTION YOU WROTE EARLIER IN THIS SET
// OF LAB EXERCISES. JUST FIND IT AND PASTE IT HERE. 

/*****     kilosToPounds     *****/
// WRITE THE kilosToPounds FUNCTION HERE.
// IT RECEIVES A WEIGHT IN KILOS AND MUST CALCULATE
// AND RETURN THE EQUIVALENT NUMBER OF POUNDS.

/*****    poundsToKilos     *****/
// WRITE THE poundsToKilos FUNCTION HERE.
// IT RECEIVES A WEIGHT IN POUNDS AND MUST CALCULATE
// AND RETURN THE EQUIVALENT NUMBER OF KILOS.
