//
//  main.swift
//  project
//
//  Created by Fabian Ortiz on 11/19/20.
//  Copyright © 2020 Fabian Ortiz. All rights reserved.
//

import Foundation

print("Hello, World!")

