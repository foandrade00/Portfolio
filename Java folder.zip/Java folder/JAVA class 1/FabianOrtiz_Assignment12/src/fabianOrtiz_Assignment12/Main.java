//Fabian Ortiz Assignment12
package fabianOrtiz_Assignment12;

public class Main {

	public static void main(String[] args) {
	    //if else statement
		int money = 2200;
	    if (money < 1000) //ternary operator
	    	{
	      System.out.println("Disney world");
	    } else if (money < 2200) {
	      System.out.println("Las Vegas");

	    }
	    int savings = 5000;
	    if (savings < 500) { //ternary operator
	    	System.out.println("Don't go on vacation");
	    
	   
	    }
	    int amount = 4; //switch statement
	    switch (amount) {
	      case 1:
	        System.out.println("You have enough for vacation"); //prints if you have more than $1000
	        break;
	      case 2:
	        System.out.println("You dont have enough for vacation"); // prints if you have less than $5000
	        break;
	      default:
	        System.out.println("Thinking about vacation?");// prints to get you thinking where do you want
	        //to go on vacation
	    } 
	}
	
	
	
	
}
