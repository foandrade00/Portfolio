package fabianOrtiz_FinalProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Demo extends JFrame implements ActionListener {

	//ActionListener will listen for the mouse clicks
	
		
		//declare a objects for each of the elements on the screen
	    JRadioButton eng, doc, prog;
	    ButtonGroup bg; //need to create button group in order to have only one button on at a time
	    JTextField jtf;
	    JCheckBox bcd, ccb, acb;
	    JTextArea jta, tb;
	    JFrame f;
	    JComboBox cb;
	    
	    Demo ()
	    {
	    	//Declare variables
	        eng = new JRadioButton ("Engineer");
	        eng.setBounds(50, 10, 100, 29);
	        doc = new JRadioButton ("Doctor");
	        doc.setBounds(50, 35, 100, 29);
	        prog = new JRadioButton ("Programmer");
	        prog.setBounds(50, 60, 100, 29);
	        bg = new ButtonGroup ();
	        bg.add (eng); //this puts the three buttons into one group
	        bg.add (doc);
	        bg.add (prog);
	        jtf = new JTextField (20);
	        jtf.setBounds(204, 47, 166, 20);
	        ccb = new JCheckBox ("Car");
	        ccb.setBounds(68, 87, 74, 23);
	        acb = new JCheckBox ("Aeroplane");
	        acb.setBounds(67, 140, 99, 23);
	        jta = new JTextArea (3, 20);
	        jta.setBounds(206, 86, 164, 77);
	        tb = new JTextArea(3, 20);
	        tb.setBounds(204, 208, 164, 22);

	        String country[] ={ "Nashville", "Miami", "Denver", "Detroit", "Chicago" };
	        cb = new JComboBox (country);
	        cb.setBounds (50, 210, 90, 20);
	        Container c = this.getContentPane ();
	        // Registering the listeners with the components
	        eng.addActionListener (this);
	        doc.addActionListener (this);
	        prog.addActionListener (this);
	        ccb.addActionListener (this);
	        acb.addActionListener (this);
	        cb.addActionListener (this);
	        getContentPane().setLayout(null);
	        c.add (eng); //see above...c is the container for the content pane
	        c.add (doc);
	        c.add (prog);
	        c.add (jtf);
	        c.add (ccb);
	        c.add (acb);
	        c.add (cb);
	        bcd = new JCheckBox ("Bike");
	        bcd.setBounds(68, 113, 74, 23);
	        bcd.addActionListener (this); //added ActionListener to capture clicks
	        c.add (bcd);
	        c.add (jta);
	        c.add (tb);
	        this.setVisible (true);
	        this.setSize (500, 500);
	        this.setTitle ("Selection Example"); // this is the entire form
	        this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	    }
	    
	    
	    public void actionPerformed (ActionEvent ae) //radiobuttons and checkboxes have actionlisteners - see above
	    {

	        if (ae.getSource () == eng)
	        {
	         jtf.setText ("You are an Engineer");
	        }
	        if (ae.getSource () == doc)
	        {
	         jtf.setText ("You are an Doctor");
	        }
	        if (ae.getSource () == prog)
	        {
	         jtf.setText ("You are an Programmer");
	        }
	        String str = " ";
	        if (bcd.isSelected ())
	        {
	         str += "Bike\n";
	        }
	        if (ccb.isSelected ())
	        {
	         str += "Car\n";
	        }
	        if (acb.isSelected ())
	        {
	         str += "Aeroplane\n";
	        }
	        Object source = ae.getSource();
	        if (source instanceof JComboBox) 
	        {
	         tb.setText(cb.getSelectedItem() + " selected");
	        }
	        jta.setText (str);

	        
	}
	    

	    public static void main (String[]args)
	    {
	        new Demo();
	    }
	
}
