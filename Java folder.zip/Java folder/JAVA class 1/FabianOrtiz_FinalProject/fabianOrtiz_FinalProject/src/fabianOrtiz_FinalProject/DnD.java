package fabianOrtiz_FinalProject;
import java.awt.EventQueue;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.TransferHandler;

public class DnD extends JFrame {
	
	
	private JTextField field;
	private JButton button;
	
	public DnD() {
		
		initUI();
		
	}

	private void initUI() {
		setTitle("Drag and Drop");
		
		button = new JButton("Button");
		field = new JTextField(15);
		
		field.setDragEnabled(true);
		button.setTransferHandler(new TransferHandler ("text"));
		
		createLayout (field, button);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}

	private void createLayout(JComponent ... arg) {
		var pane = getContentPane();
		var gl = new GroupLayout (pane);
		pane.setLayout(gl);
		
		gl.setAutoCreateContainerGaps(true);
		gl.setAutoCreateGaps(true);
		
		gl.setHorizontalGroup(gl.createSequentialGroup()
				.addComponent(arg[0])
				.addComponent(arg[1])
				);
		gl.setVerticalGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
				.addComponent(arg[0])
				.addComponent(arg[1])
				);
	
		pack();
	}
	
	public static void main (String [] args) {
	
		EventQueue.invokeLater(() -> {
			
			var ex = new DnD();
			ex.setVisible(true);
			
	});
	
}
	
}
