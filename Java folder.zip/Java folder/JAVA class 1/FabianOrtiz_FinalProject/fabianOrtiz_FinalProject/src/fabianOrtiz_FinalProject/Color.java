package fabianOrtiz_FinalProject;
import java.awt.event.*;    
import java.awt.*;    
import javax.swing.*;     
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Color extends JFrame implements ActionListener{

private static Color RED;
JButton b;
Container c;
Color() {

	
c=getContentPane();
c.setLayout (new FlowLayout ());
b = new JButton ("color");
b.addActionListener(this);
c.add(b);
}
public void actionPerformed(ActionEvent e) {
java.awt.Color initialcolor = Color.RED;
java.awt.Color color = JColorChooser.showDialog(this, "Select a color", initialcolor);
c.setBackground(color);


	
}   

public static void main(String [] args) {
Color ch = new Color();
ch.setSize(500,500);
ch.setVisible(true);
ch.setDefaultCloseOperation(EXIT_ON_CLOSE);

}
}



