package FINAL;

import org.eclipse.swt.widgets.Display;

import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
public class LEVEL3 {

	protected Shell shell;
	private Text text;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			LEVEL3 window = new LEVEL3();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		
		}
	}
	// gives correct answer
		String p= " New England Patriots"
				if (p.equals(" New England Patriots"){
					System.out.println("Next level");
				}
					else {
						System.out.println("You Lose");
						
					 }
				
	

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		text = new Text(shell, SWT.BORDER); //text box to enter answer
		text.setBounds(113, 39, 276, 27);
		
		
		//sets image where label is supposed to be
		
		JLabel lblNewLabel = new JLabel("");
		new ImageIcon(this.getClass().getResource("/sports3png.png")).getImage();
		
		lblNewLabel.setBounds(74, 125, 137, 137);
		lblNewLabel.setText("New Label");}
		
		// leads us to be able to click next button
		public void widgetSelected(SelectionEvent e) { //allows us to travel from main to level one, etc
			Object btnStart;
			if(e.getSource() ==btnStart) {
				shell.dispose();
				Object sp;
				((Object) sp).start();
			
			}
			//button to continue and go to win or lose screen
		Button btnNext = new Button(shell, SWT.NONE); //new button
		btnNext.setBounds(292, 139, 96, 27);
		btnNext.setText("NEXT");

	}

}
