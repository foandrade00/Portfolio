package FINAL;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;

public class LEVEL1 {

	protected Shell shell;
	private Text txtTennessee;
	private Text txtEnterTeamName;
	private Button btnNext;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			LEVEL1 window = new LEVEL1();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void open() {
		// TODO Auto-generated method stub
		
	}

	
	
		
		
	
	String t= "Titans"
			if (t.equals("Titans"){
				System.out.println("Next level");
			}
				else {
					System.out.println("You Lose");
					
				 }
			
					
	/**
	 * Open the window.
	 */
	public void open1() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		txtTennessee = new Text(shell, SWT.BORDER);
		txtTennessee.setEditable(false);
		txtTennessee.setText("TENNESSEE");
		txtTennessee.setBounds(93, 107, 84, 19);
		
		txtEnterTeamName = new Text(shell, SWT.BORDER);
		txtEnterTeamName.setText("ENTER TEAM NAME:");
		txtEnterTeamName.setBounds(224, 107, 182, 19);
		
		ProgressBar progressBar = new ProgressBar(shell, SWT.NONE);
		progressBar.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		progressBar.setBounds(145, 0, 140, 31);
		
		//sets image
		
		JLabel lblNewLabel = new JLabel("");
		new ImageIcon(this.getClass().getResource("sports2.jpeg")).getImage();
		
		lblNewLabel.setBounds(145, 147, 153, 115);
		lblNewLabel.setText("New Label");
		
		btnNext = new Button(shell, SWT.NONE);
		btnNext.setBounds(331, 182, 96, 27);
		btnNext.setText("NEXT");

	}
}
