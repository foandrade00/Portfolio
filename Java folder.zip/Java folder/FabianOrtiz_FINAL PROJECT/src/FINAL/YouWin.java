package FINAL;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;

public class YouWin {

	protected Shell shell;
	private Text txtYouWin;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			YouWin window = new YouWin();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		txtYouWin = new Text(shell, SWT.BORDER);
		txtYouWin.setEditable(false);
		txtYouWin.setText("YOU WIN!");
		txtYouWin.setBounds(58, 10, 338, 130);
		
		Button btnMainMenu = new Button(shell, SWT.NONE);
		btnMainMenu.setBounds(174, 169, 96, 27);
		btnMainMenu.setText("Main Menu");

	}

}
