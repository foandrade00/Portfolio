package FINAL;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Button;

public class MAIN {

	protected Shell shell;
	private Text txtEnterName;
	private Text txtMainMenu;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {// calls everything into place
		try {
			MAIN window = new MAIN();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	


	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		txtEnterName = new Text(shell, SWT.BORDER); //textbox
		txtEnterName.setText("ENTER NAME:");
		txtEnterName.setBounds(205, 71, 96, 19);
		
		Button btnStart = new Button(shell, SWT.NONE); //button
		btnStart.setBounds(205, 151, 96, 27);
		btnStart.setText("START");
		
		btnStart.addSelectionListener((SelectionListener) new SelectionAdapter() {
		private Object sp() {
			return null;
		
		}
		public void widgetSelected(SelectionEvent e) { //allows us to travel from main to level one, etc
			Object btnStart;
			if(e.getSource() ==btnStart) {
				shell.dispose();
				Object sp;
				((Object) sp).start();
			
			}
		
		
		txtMainMenu = new Text(shell, SWT.BORDER);// creates main 
		txtMainMenu.setEditable(false);
		txtMainMenu.setText("Main Menu");
		txtMainMenu.setBounds(136, 0, 204, 39);

	
		}

}