package FINAL;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;

public class LEVEL2 {

	protected Shell shell;
	private Text text;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			LEVEL2 window = new LEVEL2();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		
		}
	}
	//gives answer
		String c= "ChicaoBears"
				if (c.equals("Chicago Bears"){
					System.out.println("Next level");
				}
					else {
						System.out.println("You Lose");
						
					 }
				
	

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		//sets image where label was supposed to be
		
		JLabel lblNewLabel = new JLabel("");
		new ImageIcon(this.getClass().getResource("sports1.png")).getImage();
		
		lblNewLabel.setBounds(132, 141, 179, 100);
		lblNewLabel.setText("New Label");
		
		//text box
		text = new Text(shell, SWT.BORDER);
		text.setBounds(73, 62, 298, 36);
		
		//goes to final level
		Button btnNext = new Button(shell, SWT.NONE);
		btnNext.setBounds(329, 132, 96, 27);
		btnNext.setText("Next");

	}

}
