package FINAL;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;

public class YouLose {

	protected Shell shell;
	private Text txtYouLose;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			YouLose window = new YouLose();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		txtYouLose = new Text(shell, SWT.BORDER);
		txtYouLose.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		txtYouLose.setEditable(false);
		txtYouLose.setText("You Lose :(");
		txtYouLose.setBounds(165, 31, 192, 131);
		
		Button btnMainMenu = new Button(shell, SWT.NONE);
		btnMainMenu.setBounds(187, 190, 96, 27);
		btnMainMenu.setText("Main Menu");

	}

}
