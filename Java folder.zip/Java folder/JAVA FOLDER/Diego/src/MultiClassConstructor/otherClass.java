package MultiClassConstructor;

public class otherClass {

	    public static void main(String[] args) {
	        user player = new user();
	        player.setName("Brian Goebel");
	        // set score 100
	        player.setScore(100);

	        System.out.println(player);

	        // increment score by 10
	        player.setScore(player.getScore() + 10);
	        System.out.println("Updated score of player: " + player.getScore());
	        
	        
	    }
	}