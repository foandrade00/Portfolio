package SimpleConstructor;

public class Sample {

	  int modelYear;
	  String modelName;

		  public Sample(int year, String name) { //constructor
		    this.modelYear = year;
		    this.modelName = name;
		  }

		  public static void main(String[] args) {
		    Sample myCar = new Sample(1969, "Mustang"); //instantiation

		    System.out.println(myCar.modelYear + " " + myCar.modelName);
		    myCar.modelYear = 1985;
		    System.out.println(myCar.modelYear + " " + myCar.modelName);
		    myCar.modelName = "Chevy Truck";
		    System.out.println(myCar.modelYear + " " + myCar.modelName);
		  }
		  

}
	
