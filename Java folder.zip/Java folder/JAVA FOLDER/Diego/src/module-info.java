module Diego {
}