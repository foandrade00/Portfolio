package Attempt2;



public class Main { //the class is named Main
	//declare the variables globally in the class
	  static String productName; 
	  static String productName2;
	  static int x = 3;
	  static int y = 5;

	  public Main(String fruit, String drink) { //the constructor is named Main with two variables
	//assign the variables that were passed to the constructor to the global variables in the class
	    productName = fruit;
	    productName2 = drink;
	  }

	  public static void Message() { //should have been lower case message
		  System.out.println("Best Grocery List Ever!");
	  }

	  public static void Add() { //should have been lower case add
		  int g = Main.x + Main.y; //g declared local within Add method
		  System.out.println("From the Add method = the total is:  " + g);
		  int x = Main.x + Main.y; //g declared local within Add method
		  System.out.println("From the Add method = the total is:  " + x);
	  }
	  
	  public static void subtract() {
		  
		  int g = Main.x - Main.y; //g declared local within subtract method
		  System.out.println("From the subtract method - the total is: " + g);
	  }
		  
		  
	  public static void main(String[] args) {
		Message();

	    Main obj = new Main("apple", "cranberry"); //instantiate the constructor and call it obj
	    
		Add(); //call the Add function - should be lowercase to start a method/function
		subtract();
	    System.out.println(obj.productName + " " + obj.productName2);
	  }
	}