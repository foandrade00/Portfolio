package StaticVNonStatic;

public class Library {
public static void main(String[] args)
{
	
	String forPrinting = "";
	Book JavaStatic = new Book(); //create an instance of the other class in this package
	
	Book.getPublisher();
	
	forPrinting = JavaStatic.getPublisher();
	
	System.out.println("The book publisher is: " + forPrinting);
	
	//Book.getTitle(); //this raises an error because getTitle is non-static
	
	forPrinting = JavaStatic.getTitle();
	
	System.out.println("The book title is: " + forPrinting);
	
	//JavaHelloWorld(); //this raises an error because the method JavaHelloWorld is not static, but main is static
	
	Library trevecca = new Library(); // create an instance of the class Library (the class we are currently in)
	
	trevecca.JavaHelloWorld(); //this is OK because it is calling an instance of a static class created above
	


	
}


public void JavaHelloWorld()
{
	System.out.println("Hello World from Java");
}
}
