package StaticVNonStatic;

public class Book {
private static String publisher = "Elsevier"; //static variable is also known as a class variable
private String title = "Programming in Java"; //non-static variable is also knows as an instance variable

public static String getPublisher() //note that static method can access static / class variable
{
	return publisher;
}

public String getTitle() //note non-static methods can access static and non-static variables (class and instance variables)
{
	return title;
}
}
