
public class Info {

	public Info() {
		// TODO Auto-generated constructor stub
	}

}
