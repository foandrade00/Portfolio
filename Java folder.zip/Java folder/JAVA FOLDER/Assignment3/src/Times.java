
public class Times {

	public Times() {
		// TODO Auto-generated constructor stub
	}

}
