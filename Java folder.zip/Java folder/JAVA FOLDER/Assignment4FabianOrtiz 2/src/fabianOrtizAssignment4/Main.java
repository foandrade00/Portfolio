//Fabian Ortiz
package fabianOrtizAssignment4;

public class Main { //main class

	static String plateName;
	static String dessertName;
	static int x = 15;
	static int y = 7;
	
	public Main (String carbonara, String cake) { // started off as prices for food
	
		plateName = carbonara;
		dessertName = cake;	
	}
	
	public static void message() // message declared local
	{
		System.out.println (" Best Combo in Nashville!");
		
	}
	
	public static void add() {
		int p = Main.x + Main.y;
		System.out.println("Total cost is:" + p);
		
		int x = Main.x + Main.y;
		System.out.println("Total cost is:" + x);
	}
	
	public static void subtract()
	{
		int p = Main.x - Main.y;
		System.out.println("Total cost is:" + p);
	}
	
	public static void divide()
	{
		int p = Main.x / Main.y;
		System.out.println("From being divided, the total is:" + p);
	}
	
	public static void multiply()
	{
		int p = Main.x * Main.y;
		System.out.println("From being multiplied, the total is:" + p);
	}

	public static void modulous()
	{
		int p = Main.x % Main.y;
		System.out.println("From modulous, the total is:" + p); 
	}
	public static void squareroot() 
	{
	double p = Math.sqrt(Main.x);
	System.out.println("From the squareroot, the total is:" + p);
		
	}
	public static void absolutevalue()
	{
		double p = Math.abs(Main.x);
		System.out.println("Absolute Value is:" + p);
		
	}
	
	public static void cuberoot() 
	{
	double p = Math.cbrt(Main.x);
	System.out.println("From the cuberoot, the total is:" + p);
		
	}
	public static void round()
	{
		int p = Math.round(Main.x);
		System.out.println("Rounded Total" + p);
		
	}
	
	public static void exponent()
	{
		Math.pow(x,2);
		System.out.println("Answer in exponent:" );
		
		
	}
	
	public static void sin() // sin not applicable but part of math library
	{
		Math.sin(x);
		System.out.println("Sine answer is:");
	}
	
	public static void cos() //cosine not applicable but part of math library
	{
		Math.cos(x);
		System.out.println("Cosine answer is:");
	}
	public static void tan() //tangent not applicable but part of math library
	{
		Math.tan(x);
		System.out.println("Tangent answer is:");
	}
	
	public static void random() //random number
	{
		Math.random();
		System.out.println("Random Number is");
	}
	
	public static void Fibonacci(int num) //Fibonacci sequence
	{
		int x, y= 0, p = 1;
		for( int i = 1; i <=num;i++) {
			System.out.println(p);
			x = y;
			y = p;
			p = x + y;
			
		}
		
	}
	
	
	public static void main(String [] args)
	{
		message();
		add();
		subtract();
		multiply();
		divide();
		modulous();
		squareroot();
		absolutevalue();
		cuberoot();
		round();
		exponent();
		sin();
		cos();
		tan();
		random();
		Fibonacci(x);
		
		
	}
}
