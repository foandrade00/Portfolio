//Fabian Ortiz 
package week3Assignment;

public class Weight {
	static void myMethod() {
		
		//here the method is being used to show the weight and include 5 data samples
		
		//method is being used to create data for weight
		
		int[] myWeight = {160, 158, 164, 161, 162};
		
	 
		
		System.out.println("My weight fluctuates between this amount of weight:" + "" + myWeight.length);
		System.out.println("The weights are:" + "" + (myWeight[0]) + "," 
		+ (myWeight[1])+ "," + (myWeight[2]) + ","+ (myWeight[3]) + "," + (myWeight[4]));
		
	}
}
