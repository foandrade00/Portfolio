package week3Assignment;

//constructor

public class Main {

	//the constructor here is being used to create an object of the Main Class
	
	public static void main (String[] args) {
		Data myData =new Data ("Fabian", "Ortiz");
		System.out.println("First Name:" +" " + myData.firstName + " " + "Last Name:" + " " + myData.lastName);
		Weight.myMethod();
	}
}
