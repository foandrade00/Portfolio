//Fabian Ortiz
package week3Assignment;

public class Data {

	//in here the method was used to call a string and demonstrate its value
	
	String firstName;
	String lastName;
	
	public Data(String fName, String lName) {
		firstName = fName;
		lastName = lName;
		
		
	
	}
	
}
