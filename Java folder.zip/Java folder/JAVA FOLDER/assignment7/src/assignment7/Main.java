package assignment7;

public class Main {
	 static void myMethod() {
		 System.out.println("Here is the assignment");
		
		 //ternary operator
		  int sum1 = 150 + 100;
		    int sum2 = sum1 + 320;
		    int sum3 = sum2 + sum2;
		    System.out.println(sum1);
		    System.out.println(sum2);
		    System.out.println(sum3);
	 
		//if else statement    
		    int time = 22;
			if (time < 10) {
			  System.out.println("Good morning!");
			} else if (time < 20) {
			  System.out.println("Good afternoon!");
			} else {
			  System.out.println("Good night!");
			}
	 
			//switch statement
			int day = 4;
			switch (day) {
			  case 1:
			    System.out.println("Monday");
			    break;
			  case 2:
			    System.out.println("Tuesday");
			    break;
			  case 3:
			    System.out.println("Wednesday");
			    break;
			  case 4:
			    System.out.println("Thursday");
			    break;
			  case 5:
			    System.out.println("Friday");
			    break;
			  case 6:
			    System.out.println("Saturday");
			    break;
			  case 7:
			    System.out.println("Sunday");
			    break;
			}
	 
			
	 }
	 
	
	  
	 public static void main(String[] args) {
		 myMethod();
		  
		 //for each loop
		 String[] cars = {"Ferrari", "Lamborgini", "Porsche", "Bugatti"};
		    for (String i : cars) {
		      System.out.println(i);
		    }    
		   
		    //while loop
		    int i = 0;
		    while (i < 5) {
		      System.out.println(i);
		      i++;
		    }  
		    
		    // do while loop
		    int j = 1;
		    do {
		      System.out.println(i);
		      j++;
		    }
		    while (j < 7);  
		  
	 		

	 
	      //for loop
	 		for(int k = 0; k < 5; k++) {
	 			System.out.println(k);
	 		}
	 		}
}



	  
	 
	 


