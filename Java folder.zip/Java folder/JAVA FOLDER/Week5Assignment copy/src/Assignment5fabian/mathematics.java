package Assignment5fabian;

public class mathematics {

}
