
public class Calculation {

}
