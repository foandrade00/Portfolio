package Week1Assignment;

public class Week1Assignment {
	public static void main(String[] args) {
		System.out.println("Hello, my name is Fabian Ortiz");
	}
}


 