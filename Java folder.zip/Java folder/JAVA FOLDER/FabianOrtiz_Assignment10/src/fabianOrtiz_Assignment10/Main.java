package fabianOrtiz_Assignment10;

import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ArrayList;
public class Main {
	  ArrayList<String> currency = new ArrayList<String>()
			  currency.add("USD");
	  currency.add("EUR");// Adding objects in array
	  currency.add("AUD");
	  currency.add("EUR");
	   System.out.println("currencies:");// prints out array list
	   
	    


	 public static void main(String[] args) {
		   //States the values of the dictionary and 
	        //contents of the dictionary
		 Dictionary<String, String> countryCurrency = new Hashtable<>();
	        //Established values
	        countryCurrency.put("USA", "USD");
	        countryCurrency.put("Austria", "EUR");
	        countryCurrency.put("Australia", "AUD");
	        countryCurrency.put("France", "EUR");

	        Enumeration<String> keys = countryCurrency.keys();

	        while (keys.hasMoreElements()) {
	            String key = keys.nextElement();
	            if (key.startsWith("Aus")) // will delete all the other keys so meets requirements
	            	{
	                String value = countryCurrency.get(key);
	               System.out.println("Key : " + key + ", Value : " + value);
	          
	            	
	      }
	            
	       
	        }

	    }
	
}
