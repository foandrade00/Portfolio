package assignment5FabianOrtiz;

import java.util.Scanner;

public class Mathematic {

	

	public static void main(String args[] )
	{
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the radius:");
		double r = s.nextDouble();
		double area = (22*r*r)/7;
	
		System.out.println("Area of a circle is: " + area);
		
		//Surface area and volume of sphere
		
		double radius, sa, Volume;
		
		
		System.out.println("Please enter the radius of a sphere:");
		radius = s.nextDouble();
		
		sa = 4 * Math.PI * radius * radius;
		Volume = (4.0 / 3) * Math.PI * radius * radius * radius;
		System.out.format("The surface area of a sphere = %.2f", sa);
		System.out.format("\n The volume of a sphere = %.2f", Volume);
		
		
		//Diameter
		double diameter;
		
		
		System.out.print("Enter radius of circle:");
		radius = s.nextDouble();
		//Calculates diameter
		diameter = 2 * radius;
		
		System.out.println("Diameter of circle = "+diameter+" units ");
		
		
		
		//Volume of Cylinder
		
		//Input 
		System.out.println("Enter Height of the cylinder:= ");
		double height = s.nextDouble();
		
		System.out.println("Enter the radius of  the cylinder: = ");
		//Calculation
		double volume = Math.PI*(radius*radius)*height;
		
		System.out.println("Volume of cylinder=" + volume);
		s.close();
		
	}

	/*Enter the radius:
		2
		Area of a circle is: 12.571428571428571
		Please enter the radius of a sphere:
		2
		The surface area of a sphere = 50.27
		 The volume of a sphere = 33.51Enter radius of circle:2
		Diameter of circle = 4.0 units 
		Enter Height of the cylinder:= 
		2
		Enter the radius of  the cylinder: = 
		Volume of cylinder=25.132741228718345*/

}
