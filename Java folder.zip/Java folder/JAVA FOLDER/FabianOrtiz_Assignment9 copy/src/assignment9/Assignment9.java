package assignment9;

import java.util.Arrays;
import java.util.*;  
public class Assignment9 {

	  public static void main(String[] args) {
	       
		 //this is where we declared the array and added the string values
		  String[] days = {
"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
	 
     	  
    	  
	        
		  // here we have what will print out the days of the week
	       for (int i = 0; i < 7; i++) {
	           System.out.println(days[i]);
	           	
	       //Sort method, used to sort days of the week   
	       Arrays.sort(days, Collections.reverseOrder());
	       
	       //I used this sort method and didn't need a for loop since it sorted it fine
	      }
	       //separate method that allows me to print the last two requirements
	      
	       System.out.println("Your Name's Favorite day of the week is Thursday");
	       System.out.println("My name is Fabian Ortiz and my favorite day of the week is Saturday");
	     
	      
	  	}	  
	}
