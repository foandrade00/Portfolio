package assignment8;

import java.util.Scanner;

public class Assignment {

	public static void Main(String [] args)
	{
		 Scanner s = new Scanner(System.in);
	        System.out.print("Enter first number: ");
	        //Multiplication
	        // This method reads the number provided using keyboard
	        double num1 = s.nextDouble();
	        
	        System.out.print("Enter second number: ");
	        double num2 = s.nextDouble();
	        
	        // Calculating product of two numbers
	        double product = num1*num2;
	        
	        // Displaying the multiplication result
	        System.out.println("Output: "+product);
	        	s.close();
	
	       //Addition
	        System.out.println("Enter Two Numbers (Press Enter after each):");
	        //two variables to hold numbers
	        double n1, n2, n3;
	        n1 = s.nextDouble();
	        n2 = s.nextDouble();
	        n3 = n1 + n2;
	        System.out.println("Total = " + n3);
	

	     
	         
	         //Division 
	          System.out.print("Enter the value to num1: ");
	          int num4= s.nextInt();
	          //store the first input in number 1
	          System.out.print("Enter the value to num2: ");
	          int num5= s.nextInt();
	          //store the first input in number 1
	          int result=num4/num5;//calculate the division
	          System.out.println("Division of "+num4+" and "+num5+" is:"+result);
		  
	          //Comparison operators
	          int number1; // first number to compare       
	          int number2; // second number to compare  
	        
	          System.out.print( "Input first integer: " ); // prompt        
	          number1 = s.nextInt(); // read first number from user   
	   
	          System.out.print( "Input second integer: " ); // prompt        
	          number2 = s.nextInt(); // read second number from user               
	          
	          if ( number1 == number2 )           
	              System.out.printf( "%d == %d\n", number1, number2 );  
	          if ( number1 != number2 )          
	              System.out.printf( "%d != %d\n", number1, number2 );  
	          if ( number1 < number2 )          
	              System.out.printf( "%d < %d\n", number1, number2 );  
	          if ( number1 > number2 )          
	              System.out.printf( "%d > %d\n", number1, number2 );  
	          if ( number1 <= number2 )          
	              System.out.printf( "%d <= %d\n", number1, number2 );  
	          if ( number1 >= number2 )          
	              System.out.printf( "%d >= %d\n", number1, number2 );  
	          
	          
	          
	          //Logical operators
	          int a = 10, b = 20, c = 20, d = 0;
	    
	          // Displaying a, b, c
	          System.out.println("Var1 = " + a);
	          System.out.println("Var2 = " + b);
	          System.out.println("Var3 = " + c);
	    
	          // using logical AND to verify
	          // two constraints
	          if ((a < b) && (b == c)) {
	              d = a + b + c;
	              System.out.println("The sum is: " + d);
	          }
	          else
	              System.out.println("False");
	          
	          
	          //- Unary 
	          // variable declaration
	          int n6 = 20;
	    
	          System.out.println("Number = " + n1);
	    
	          // Performing unary operation
	          n6 = -n6;
	    
	          // Print the result number
	          System.out.println("Result = " + n1);
	          
	          //Unary Not-Operator
	          boolean condition = true;
	          int n7 = 10, n8 = 1;
	    
	          // Displaying condition, a, b
	          System.out.println("Condition is: " + condition);
	          System.out.println("Var1 = " + n7);
	          System.out.println("Var2 = " + n8);
	    
	          // Using unary NOT operator
	          System.out.println("Now cond is: " + !condition);
	          System.out.println("!(a < b) = " + !(n7 < n8));
	          System.out.println("!(a > b) = " + !(n7 > n8));
	          
	          //Increment operator
	          int num = 5;
	          
	          // first 5 gets printed and then increases to 6
	         
	          System.out.println("After "
	                             + "increment = " + num++);
	    
	          // number was 6, incremented to 7
	          // then printed
	          System.out.println("Before "
	                             + "increment = " + ++num);
	          
	       
	          //Decrement operator
	          // first 5 gets printed and then decremented to 4
	         
	          System.out.println("After "
	                             + "decrement = " + num--);
	    
	          System.out.println("num = " + num);
	    
	          // number was 4, decremented to 3
	          // then printed
	          System.out.println("Before "
	                             + "decrement = " + --num);
	}
	
}
